const video = document.getElementById('video');
const captureButton = document.getElementById('captureButton');
const uploadInput = document.getElementById('uploadInput');
const uploadButton = document.getElementById('uploadButton');
const displayedImage = document.getElementById('displayedImage');
const secondImage = document.getElementById('secondImage');

// Start webcam feed
navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
        video.srcObject = stream;
    })
    .catch((error) => {
        console.error('Error accessing webcam:', error);
        alert('Could not access the webcam.');
    });

// Capture image from webcam
captureButton.addEventListener('click', () => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Set the captured image as the source for both displays
    const imageData = canvas.toDataURL('image/png');
    displayedImage.src = imageData;
    secondImage.src = imageData;
    displayedImage.style.display = 'block';
    secondImage.style.display = 'block';
});

// Show file input when "Upload from Gallery" button is clicked
uploadButton.addEventListener('click', () => {
    uploadInput.click();
});

// Handle gallery upload
uploadInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();

        reader.onload = (e) => {
            // Set the uploaded image as the source for both displays
            const imageData = e.target.result;
            displayedImage.src = imageData;
            secondImage.src = imageData;
            displayedImage.style.display = 'block';
            secondImage.style.display = 'block';
        };

        reader.readAsDataURL(file);
    } else {
        alert("Please select a valid image file.");
    }
});

// Make the second image resizable by dragging
secondImage.addEventListener('mousedown', function(e) {
    let initialWidth = secondImage.offsetWidth;
    let initialHeight = secondImage.offsetHeight;
    let initialX = e.clientX;
    let initialY = e.clientY;

    const onMouseMove = (moveEvent) => {
        const deltaX = moveEvent.clientX - initialX;
        const deltaY = moveEvent.clientY - initialY;

        // Calculate new width and height
        secondImage.style.width = initialWidth + deltaX + 'px';
        secondImage.style.height = initialHeight + deltaY + 'px';
    };

    const onMouseUp = () => {
        window.removeEventListener('mousemove', onMouseMove);
        window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
});
